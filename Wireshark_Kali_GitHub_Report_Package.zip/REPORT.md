# Wireshark Network Traffic Analysis Report

**Platform:** Kali Linux  
**Tool:** Wireshark  
**Interface:** `eth0`  
**Capture shown:** `wireshark_eth08FWAZ3.pcapng`  
**Packets:** 44 (status bar)  
**Observed duration:** approximately 15 seconds  
**Client:** `192.168.197.128`  
**DNS resolver:** `192.168.197.2`

## 1. Objective

Analyze the supplied Wireshark capture screenshots using display filters, identify the protocols and endpoints visible, and document relevant network-security observations.

## 2. Filters applied

| Filter | Purpose |
|---|---|
| `ip.addr == 192.168.197.128` | Show traffic involving the client |
| `ip.src == 192.168.197.128` | Show packets sourced by the client |
| `ip.dst == 192.168.197.2` | Show packets directed to the DNS resolver |
| `ip.addr == 192.168.197.1` | Isolate traffic involving this local endpoint |
| `udp.port == 53` | Show UDP DNS traffic |
| `udp.dstport == 53` | Show requests sent to destination port 53 |
| `dns` | Show DNS queries and responses |
| `icmp` | Inspect ICMP errors |
| `ntp` | Inspect time synchronization |
| `mdns` | Inspect multicast DNS |

## 3. Observations

### DNS

- Client `192.168.197.128` communicates with resolver `192.168.197.2`.
- Queries include A and AAAA lookups for `wpad.localdomain`.
- A lookup for `debian.pool.ntp.org` is visible.
- The displayed response includes A records `162.159.200.1`, `95.216.144.226`, `192.46.211.253`, and `192.46.210.39`.
- WPAD-related requests shown in the screenshots receive negative “No such name” responses.

### WPAD, mDNS and LLMNR

- Repeated lookups for `wpad`, `wpad.local` and `wpad.localdomain` are visible.
- mDNS traffic is sent to `224.0.0.251` and IPv6 multicast `ff02::fb`.
- LLMNR traffic is sent to `224.0.0.252`.
- These are local discovery mechanisms. WPAD discovery can be security-relevant because an attacker on an inadequately controlled local network may attempt to spoof name resolution and provide an unwanted proxy configuration.
- No successful spoofing or malicious proxy response is established by these screenshots.

### ICMP

- One packet is labelled `Destination unreachable (Port unreachable)`.
- The displayed source is `192.168.197.128`; destination is `192.168.197.2`.
- The screenshots do not establish the underlying cause. Inspect the quoted original UDP header in the PCAPNG for more detail.

### NTP

- Two NTPv4 client requests are visible.
- Destinations: `162.159.200.1` and `95.216.144.226`.
- NTP uses UDP destination port 123.
- The supplied filtered views show requests; they do not confirm corresponding replies.

## 4. Security assessment and recommendations

| Area | Recommendation |
|---|---|
| WPAD | Disable WPAD if it is not required; use centrally managed proxy settings. |
| LLMNR / mDNS | Disable or restrict where not operationally required; monitor unexpected responders. |
| DNS | Review resolver policy and confirm that local name-resolution behaviour is expected. |
| ICMP | Inspect the complete ICMP packet and embedded UDP header in the original PCAPNG. |
| NTP | Confirm configured time sources and successful synchronization on the host. |

## 5. Conclusion

The capture is primarily local name-resolution and time-synchronization traffic. Repeated WPAD discovery is the most security-relevant pattern and merits review on networks where LLMNR/mDNS or automatic proxy discovery are unnecessary. However, the supplied screenshots do not prove compromise, credential theft, malware, or a successful spoofing attack.

## 6. Limitations

This report is based on 14 screenshots, not direct parsing of the original PCAPNG. Conclusions are limited to visible packet summaries and details. The original capture file is not included in this repository package.

## 7. Evidence

See [`screenshots/`](screenshots/) and the PDF report for the Wireshark filter views and packet-detail evidence.
