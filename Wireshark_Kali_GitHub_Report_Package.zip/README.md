# Wireshark Network Traffic Analysis — Kali Linux

A defensive network-traffic analysis report created from Wireshark screenshots captured on Kali Linux.

## Contents

- `Wireshark_Network_Traffic_Analysis_Report.pdf` — full analysis report with findings, security assessment, recommendations and screenshot appendix.
- `screenshots/` — supplied Wireshark screenshots, converted to JPEG for a smaller repository footprint.

## Capture summary

| Field | Observed value |
|---|---|
| Capture interface | `eth0` |
| Client IPv4 | `192.168.197.128` |
| DNS resolver | `192.168.197.2` |
| Capture file shown in Wireshark | `wireshark_eth08FWAZ3.pcapng` |
| Packets shown in status bar | 44 |
| Approximate displayed duration | 15 seconds |
| Protocols observed | DNS, ICMP, NTP, mDNS, LLMNR |

## Filters used

```wireshark
ip.addr == 192.168.197.128
ip.src == 192.168.197.128
ip.dst == 192.168.197.2
ip.addr == 192.168.197.1
udp.port == 53
udp.dstport == 53
dns
icmp
ntp
mdns
```

## Key findings

1. DNS queries are sent from `192.168.197.128` to `192.168.197.2`.
2. The capture includes A/AAAA lookups involving `wpad.localdomain` and a lookup for `debian.pool.ntp.org`.
3. The visible DNS response for `debian.pool.ntp.org` includes A records `162.159.200.1`, `95.216.144.226`, `192.46.211.253`, and `192.46.210.39`.
4. Repeated WPAD discovery queries appear over mDNS and LLMNR.
5. One ICMP packet is labelled `Destination unreachable (Port unreachable)`.
6. Two NTPv4 client requests are visible to `162.159.200.1` and `95.216.144.226`.

## Security note

WPAD discovery over local name-resolution protocols can create a spoofing/rogue-proxy risk on networks where these mechanisms are not controlled. The screenshots do **not** prove that spoofing, credential theft, malware activity, or compromise occurred. The ICMP packet's underlying cause also cannot be determined from the screenshots alone.

## Reproducibility

Open the original `.pcapng` file in Wireshark and apply the filters above. The report was written from the screenshots supplied for this project; the original PCAPNG was not included in this package. For deeper verification, add the original capture file (after checking it contains no sensitive traffic) and export relevant packet details.

## Tools

- Kali Linux
- Wireshark

## Author

Add your name, course, institution and date here before publishing.
